package phase1;

public class ap9arrays {

	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 4, 5};

        for (int elementpoints : arr) {
            System.out.print(elementpoints + " ");
        }

	}

}
